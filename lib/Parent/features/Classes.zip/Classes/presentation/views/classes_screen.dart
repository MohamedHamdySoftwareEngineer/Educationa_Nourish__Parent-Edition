import 'package:educational_nourish/features/Classes/presentation/views/widgets/classes_screen_body.dart';
import 'package:flutter/material.dart';

class ClassesScreen extends StatelessWidget {
  const ClassesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: ClassesScreenBody(),
    );
  }
}